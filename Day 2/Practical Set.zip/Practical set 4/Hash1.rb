# h = {a: 1, b:2, c: 3, 'd' => 4, 'e' => 5}
# print the value of key => d

h = {a: 1, b:2, c: 3, 'd' => 4, 'e' => 5}

puts h['d']