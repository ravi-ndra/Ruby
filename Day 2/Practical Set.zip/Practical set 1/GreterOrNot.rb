# Check if 10 is greater than 15 or not using conditional statement

num = 10
if num > 15
    puts "#{num} is greater than 15."
else 
    puts "#{num} is smaller than 15"
end