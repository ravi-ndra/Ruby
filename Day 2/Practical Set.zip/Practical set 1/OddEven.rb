# Check weather 10 is odd or even

num = 10
if num % 2 == 0
    puts "#{num} is Even."
else
    puts "#{num} is Odd"
end