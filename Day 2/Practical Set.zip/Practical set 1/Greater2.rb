# Check if 10 is greater than 5 or not using conditional statement

num = 10
if num > 5
    puts "#{num} is greater than 5."
else 
    puts "#{num} is smaller than 5"
end