# user input first name and last name and print reverse

f_name = gets.chomp
l_name = gets.chomp

puts "#{l_name.reverse} #{f_name.reverse}"